<?php
include_once("../funciones/seguridad/mysql_inc.php");
include_once("../funciones/adodb_time_inc.php");
include_once("../funciones/funciones.php"); /* incluye el directorio de funciones */
include_once("../clases/class.micalendario.php");
$calendario= New micalendario(); // variable de calendario.

session_start(); /* empiezo una sesi�n */

define('FPDF_FONTPATH','../fpdf17/font/');
require("../fpdf17/fpdf.php");

class PDF extends FPDF
{

// Page header
function Header()
{
    global $title1;
    global $title2;
    // Logo
    $this->Image('../fpdf17/logo.png',10,6,40);
    $this->Ln(4);
    // Title1
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title1
    $this->Cell(30,10,$title1,0,0,'C');
    $this->Ln(6);
    // title2
    // Arial bold 14
    $this->SetFont('Arial','B',13);
    // Move to the right
    $this->Cell(80);
    // Title1
    $this->Cell(30,10,$title2,0,0,'C');
    // Line break
    $this->Ln(8);
}

function Cabecera($cabecera) {    
   
    // Arial bold 15
    $this->Ln(4);	
    $this->SetFont('Arial','B',12);
    // Calculate width of title and position
    $w = $this->GetStringWidth($cabecera)+6;
    $this->SetX((210-$w)/2);
    // Colors of frame, background and text
    $this->SetDrawColor(0,0,0);
    $this->SetFillColor(220,220,220);
    // $this->SetTextColor(220,50,50);
    // Thickness of frame (1 mm)
    $this->SetLineWidth(1);
    // Title
    $this->Cell($w,9,$cabecera,1,1,'C',true);
    // Line break
    $this->Ln(4);
}

// Page footer
function Footer()
{
    global $h;
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',10);
    // Page number
    $this->Cell(0,10,'P�gina '.$this->PageNo().'/{nb} - '.$h,0,0,'C');
}

// Empieza lo de HTML

var $B;
var $I;
var $U;
var $HREF;

function PDF($orientation='P', $unit='mm', $size='A4')
{
    // Call parent constructor
    $this->FPDF($orientation,$unit,$size);
    // Initialization
    $this->B = 0;
    $this->I = 0;
    $this->U = 0;
    $this->HREF = '';
}

function WriteHTML($html)
{
    // HTML parser
    $html = str_replace("\n",' ',$html);
    $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
    foreach($a as $i=>$e)
    {
        if($i%2==0)
        {
            // Text
            if($this->HREF)
                $this->PutLink($this->HREF,$e);
            else
                $this->Write(5,$e);
        }
        else
        {
            // Tag
            if($e[0]=='/')
                $this->CloseTag(strtoupper(substr($e,1)));
            else
            {
                // Extract attributes
                $a2 = explode(' ',$e);
                $tag = strtoupper(array_shift($a2));
                $attr = array();
                foreach($a2 as $v)
                {
                    if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                        $attr[strtoupper($a3[1])] = $a3[2];
                }
                $this->OpenTag($tag,$attr);
            }
        }
    }
}

function OpenTag($tag, $attr)
{
    // Opening tag
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,true);
    if($tag=='A')
        $this->HREF = $attr['HREF'];
    if($tag=='BR')
        $this->Ln(5);
}

function CloseTag($tag)
{
    // Closing tag
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,false);
    if($tag=='A')
        $this->HREF = '';
}

function SetStyle($tag, $enable)
{
    // Modify style and select corresponding font
    $this->$tag += ($enable ? 1 : -1);
    $style = '';
    foreach(array('B', 'I', 'U') as $s)
    {
        if($this->$s>0)
            $style .= $s;
    }
    $this->SetFont('',$style);
}

function PutLink($URL, $txt)
{
    // Put a hyperlink
    $this->SetTextColor(0,0,255);
    $this->SetStyle('U',true);
    $this->Write(5,$txt,$URL);
    $this->SetStyle('U',false);
    $this->SetTextColor(0);
}

} // fin de la clase PDF

// Instanciation of inherited class
$pdf = new PDF();

// Necesito algunas variables
// obtiene arrays, por si hay que usarlos m�s de una vez. Alumnos de la TUTOR�A
$alumno=obteneralumnosasignacion($bd,$_SESSION['asignacion']); // array para introducir datos de los alumnos
$ii=count($alumno['idalumno']);

// conjunto de items
$items=obteneritems($bd);

// Obtengo la lista de asignaciones que cursan los alumnos de MI TUTOR�A
$asignaciones = obtenerasignaciones($bd,$alumno['idalumno'],$_SESSION['tutevaluacion']); // pasa un array con los id de todos los alumnos
// obtiene un array con las distintas asignaciones que ESA EVALUACI�N, han sido calificadas
$jj=count($asignaciones);

// N�mero Alumnos de la ASIGNACI�N que est� en $_SESSION['contador']
$a2=obteneralumnosasignacion($bd,$asignaciones[$_SESSION['contador']]);
$numa2=count($a2['idalumno']);

$noestan=array_diff($a2['idalumno'],$alumno['idalumno']);
$numnoestan=count($noestan);

// Empiezo el pdf
// Declaro variables
$title1 = 'Evaluaci�n: '.dado_Id($bd,$_SESSION['tutevaluacion'],"nombreeval","tb_edicionevaluaciones","ideval");
$title2= 'Clases: '.$alumno['cadenaclases'];
$horafecha='Fecha: '.$calendario->fechaformateada($calendario->fechadehoy());
$horafecha.=' - Hora: '.$calendario->horactual();
$h=$horafecha;
$cad = obtenerdatosasignacion($bd,$asignaciones[$_SESSION['contador']]);

// P�gina
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Cabecera($cad['profesor']." (".$cad['materia'].") "); // A�ade una cabecera

for ($j=0;$j<$ii;$j++) { // por cada alumno

// Recupero de la base de datos
$link=Conectarse($bd); // y me conecto. //dependiendo del tipo recupero uno u otro.

// antiguo--> $Sql='SELECT items, profesor, materia, observaciones FROM tb_evaluacion WHERE unidad= "'.$_SESSION['tutoria'].'" AND materia="'.$materia['idmateria'][$_SESSION['contador']].'" AND eval ="'.$_SESSION['tutevaluacion'].'" AND alumno ="'.$alumno['idalumno'][$j].'" AND (items<>"" OR observaciones<>"") ORDER BY profesor';

$Sql='SELECT items, observaciones,alumno, profesor,materia,asignacion  from tb_evaluacion inner join tb_asignaciones ON tb_evaluacion.asignacion=tb_asignaciones.idasignacion WHERE eval ="'.$_SESSION['tutevaluacion'].'" AND alumno ="'.$alumno['idalumno'][$j].'" AND asignacion="'.$asignaciones[$_SESSION['contador']].'" AND (items<>"" OR observaciones<>"") ORDER BY alumno';

$result=mysql_query($Sql,$link); // ejecuta la cadena sql y almacena el resultado el $result
$totalFilas = mysql_num_rows($result);  

if ($totalFilas>0) { //principio del if. Me pone el nombre del alumno

$pdf->SetFont('Times','BU',14);
$pdf->Cell(0,5,($j+1).'.- '.cambiarnombre($alumno['alumno'][$j])." - ".$alumno['unidad'][$j],0,2); // Nombre del alumno
$pdf->Ln(2);
// Hago el bucle

while ($row=mysql_fetch_array($result)) {
$pdf->SetFont('Times','B',13);
$pdf->Cell(0,5,'Profesor/a: '.cambiarnombre(dado_Id($bd,$row['profesor'],"Empleado","tb_profesores","idprofesor")),0,1);
$pdf->Ln(1);
$pdf->SetFont('Times','',13);
$itemsobtenidos=explode("#",$row['items']);
   $escribealumno="";
   $complementos="";
   foreach ($itemsobtenidos as $it) {
       $encontrar=array_search($it,$items['iditem']);
       if (!is_null($encontrar) && is_numeric($encontrar) && $items['positivo'][$encontrar]<=1) {	
	 $escribealumno.=$items['item'][$encontrar].' ['.strtoupper(substr($items['grupo'][$encontrar],0,3)).']. ';
       } else if (!is_null($encontrar) && is_numeric($encontrar) && $items['positivo'][$encontrar]>1) { // complementos
         $complementos.=$items['item'][$encontrar].' ['.strtoupper(substr($items['grupo'][$encontrar],0,3)).']. ';
       } // fin del if
   } // fin del foreach

// $pdf->Multicell(0,5,$escribealumno,0,'J');

if ($escribealumno<>"") {
  $escribealumno="<b><i>Items:</i></b> ".$escribealumno.'<br>'; 
  $pdf->SetFontSize(13);
  $pdf->WriteHTML($escribealumno); 
  #$pdf->Multicell(0,5,$escribealumno,0,'J');
}

if ($complementos<>"") {
  $complementos="<b><i>Datos complementarios:</i></b> ".$complementos.'<br>';
  // $pdf->SetLeftMargin(15);
  $pdf->SetFontSize(13);
  $pdf->WriteHTML($complementos);
}

if ($row['observaciones']<>"") {
  $incorporar="<b><i>Observaciones:</i></b> ".$row['observaciones'].'<br>';
  // $pdf->SetLeftMargin(15);
  $pdf->SetFontSize(13);
  $pdf->WriteHTML($incorporar);
}
$pdf->Ln(3);
} // fin del while  
mysql_free_result($result); // acaba por cada profesor

$pdf->Image("../fpdf17/hr-jon-lucas2.jpg",80,NULL,50);
// $pdf->Multicell(0,5,"----- o -----",0,'C');
$pdf->Ln(2);

} // fin del if

else {

} // por si quiero poner algo para los que est�n vac�os...

} // fin del for por cada alumno

$incorporar="";
if ($numnoestan>0 && $ii>0) {
$incorporar.='<b>En mi tutor�a, N� de alumnos CON esta asignatura y este profesora/a: </b>'.($numa2-$numnoestan).' - '.(round(100*($numa2-$numnoestan)/$ii,2)).'%<br>';
$incorporar.='<b>En mi tutor�a, N� de alumnos que NO TIENEN esta asignatura y este profesora/a: </b>'.($ii-$numa2+$numnoestan).'<br>';
}
if ($numnoestan>0) { $incorporar.="<b>En esta asignatura con este profesor/a hay ".$numnoestan." alumnos/as m�s que no pertenecen a esta tutor�a: </b>";}
foreach ($noestan as $key => $valor) {
  $incorporar.=cambiarnombre($a2['alumno'][$key])." - ".$a2['unidad'][$key]." // ";
}
if ($incorporar<>"") {
  $incorporar=substr($incorporar,0,strlen($incorporar)-4);
  // $pdf->SetLeftMargin(15);
  $pdf->SetFontSize(13);
  $pdf->WriteHTML($incorporar);
}

// Env�o el PDF
$pdf->Output($cad['profesor']." (".$cad['materia'].") ".' - '.$title1.'.pdf','I');

?>

