<?php
include_once("../funciones/seguridad/mysql_inc.php");
include_once("../funciones/adodb_time_inc.php");
include_once("../funciones/funciones.php"); /* incluye el directorio de funciones */
include_once("../clases/class.micalendario.php");
$calendario= New micalendario(); // variable de calendario.

session_start(); /* empiezo una sesi�n */

define('FPDF_FONTPATH','../fpdf17/font/');
require("../fpdf17/fpdf.php");

class PDF extends FPDF
{

// Page header
function Header()
{
    global $title1;
    global $title2;
    // Logo
    $this->Image('../fpdf17/logo.png',10,6,40);    
    $this->Ln(4);	
    // Title1
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title1
    $this->Cell(30,10,$title1,0,0,'C');
    $this->Ln(6);
    // title2
    // Arial bold 14
    $this->SetFont('Arial','B',13);
    // Move to the right
    $this->Cell(80);
    // Title1
    $this->Cell(30,10,$title2,0,0,'C');
    // Line break
    $this->Ln(8);
}

function Cabecera($cabecera) {    
   
    // Arial bold 15
    $this->Ln(4);	
    $this->SetFont('Arial','B',15);
    // Calculate width of title and position
    $w = $this->GetStringWidth($cabecera)+6;
    $this->SetX((210-$w)/2);
    // Colors of frame, background and text
    $this->SetDrawColor(0,0,0);
    $this->SetFillColor(220,220,220);
    // $this->SetTextColor(220,50,50);
    // Thickness of frame (1 mm)
    $this->SetLineWidth(1);
    // Title
    $this->Cell($w,9,$cabecera,1,1,'C',true);
    // Line break
    $this->Ln(4);
}

// Page footer
function Footer()
{
    global $h;
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',10);
    // Page number
    $this->Cell(0,10,'P�gina '.$this->PageNo().'/{nb} - '.$h,0,0,'C');
}

// Empieza lo de HTML

var $B;
var $I;
var $U;
var $HREF;

function PDF($orientation='P', $unit='mm', $size='A4')
{
    // Call parent constructor
    $this->FPDF($orientation,$unit,$size);
    // Initialization
    $this->B = 0;
    $this->I = 0;
    $this->U = 0;
    $this->HREF = '';
}

function WriteHTML($html)
{
    // HTML parser
    $html = str_replace("\n",' ',$html);
    $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
    foreach($a as $i=>$e)
    {
        if($i%2==0)
        {
            // Text
            if($this->HREF)
                $this->PutLink($this->HREF,$e);
            else
                $this->Write(5,$e);
        }
        else
        {
            // Tag
            if($e[0]=='/')
                $this->CloseTag(strtoupper(substr($e,1)));
            else
            {
                // Extract attributes
                $a2 = explode(' ',$e);
                $tag = strtoupper(array_shift($a2));
                $attr = array();
                foreach($a2 as $v)
                {
                    if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                        $attr[strtoupper($a3[1])] = $a3[2];
                }
                $this->OpenTag($tag,$attr);
            }
        }
    }
}

function OpenTag($tag, $attr)
{
    // Opening tag
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,true);
    if($tag=='A')
        $this->HREF = $attr['HREF'];
    if($tag=='BR')
        $this->Ln(5);
}

function CloseTag($tag)
{
    // Closing tag
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,false);
    if($tag=='A')
        $this->HREF = '';
}

function SetStyle($tag, $enable)
{
    // Modify style and select corresponding font
    $this->$tag += ($enable ? 1 : -1);
    $style = '';
    foreach(array('B', 'I', 'U') as $s)
    {
        if($this->$s>0)
            $style .= $s;
    }
    $this->SetFont('',$style);
}

function PutLink($URL, $txt)
{
    // Put a hyperlink
    $this->SetTextColor(0,0,255);
    $this->SetStyle('U',true);
    $this->Write(5,$txt,$URL);
    $this->SetStyle('U',false);
    $this->SetTextColor(0);
}

} // fin de la clase PDF

// Instanciation of inherited class
$pdf = new PDF();
// Necesito algunas variables
// obtiene arrays, por si hay que usarlos m�s de una vez
$alumno=obteneralumnosasignacion($bd,trim($_SESSION['asignacion'])); // array para introducir datos de los alumnos
$ii=count($alumno['idalumno']);
$items=obteneritems($bd);
// Empiezo el pdf

// Declaro variables
$title1 = 'Evaluaci�n: '.dado_Id($bd,$_SESSION['tutevaluacion'],"nombreeval","tb_edicionevaluaciones","ideval");
$title2 = 'Datos por alumno_a de la/las clase/s de '.$alumno['cadenaclases'];
$horafecha='Fecha: '.$calendario->fechaformateada($calendario->fechadehoy());
$horafecha.=' - Hora: '.$calendario->horactual();
$h=$horafecha;
// P�gina
$pdf->AliasNbPages();
if (isset($_GET['salto']) && $_GET['salto']<>1) { $pdf->AddPage(); } // Si no salta, al menos pone un AddPage
// Recupero de la base de datos

foreach ($alumno['alumno'] as $clave => $alum) {
// Escribe alumno
if (isset($_GET['salto']) && $_GET['salto']==1) { $pdf->AddPage(); }
$pdf->Cabecera(cambiarnombre($alum).' - '.$alumno['unidad'][$clave]);
// Busca los items de este alumno

$link=Conectarse($bd); // y me conecto. //dependiendo del tipo recupero uno u otro.
// antiguo --> $Sql='SELECT items, profesor, materia, observaciones FROM tb_evaluacion WHERE unidad= "'.$_SESSION['tutoria'].'" AND alumno="'.$alumno['idalumno'][$clave].'" AND eval ="'.$_SESSION['tutevaluacion'].'" AND (items<>"" OR observaciones<>"") ORDER BY materia, profesor';

$Sql='SELECT items, observaciones,profesor,materia  from tb_evaluacion inner join tb_asignaciones ON tb_evaluacion.asignacion=tb_asignaciones.idasignacion WHERE alumno="'.$alumno['idalumno'][$clave].'" AND eval ="'.$_SESSION['tutevaluacion'].'" AND (items<>"" OR observaciones<>"") ORDER BY materia,profesor';

$result=mysql_query($Sql,$link); // ejecuta la cadena sql y almacena el resultado el $result
while ($row=mysql_fetch_array($result)) {
$pdf->SetFont('Times','B',13);
$pdf->Cell(0,10,'Profesor/a: '.cambiarnombre(dado_Id($bd,$row['profesor'],"Empleado","tb_profesores","idprofesor")).' - Materia: '.dado_Id($bd,$row['materia'],"Materias","tb_asignaturas","idmateria"),0,1);
$pdf->SetFont('Times','',13);
   
// escribe los datos
   $escribealumno="";
   $grupo=""; 

   if (!(empty($row['items']) || is_null($row['items']))) {
   $itemsobtenidos=explode("#",$row['items']); 

   foreach ($itemsobtenidos as $it) {
       $encontrar=array_search($it,$items['iditem']);
       if ($grupo<>$items['grupo'][$encontrar] && $items['positivo'][$encontrar]<=1) { 
          if ($grupo<>"") { $escribealumno.="<br>";}
          $grupo=$items['grupo'][$encontrar];           
	  $escribealumno.= "<b><i>".$items['grupo'][$encontrar].": </i></b>";
       } 
       if (!is_null($encontrar) && is_numeric($encontrar) && $items['positivo'][$encontrar]<=1) {	
	 $escribealumno.=$items['item'][$encontrar].'. ';
       }
   } // fin del foreach
   // repito el foreach para poner los neutrales
   $escribealumno.="<br>";
   $grupo="";
   foreach ($itemsobtenidos as $it) {
       $encontrar=array_search($it,$items['iditem']);
       if ($grupo<>$items['grupo'][$encontrar] && $items['positivo'][$encontrar]>1) { // as� se ponen los neutrales
          if ($grupo<>"") { $escribealumno.="<br>";}
          $grupo=$items['grupo'][$encontrar];           
	  $escribealumno.= "<b><i>".$items['grupo'][$encontrar].": </i></b>";
       } 
       if (!is_null($encontrar) && is_numeric($encontrar) && $items['positivo'][$encontrar]>1) {	
	 $escribealumno.=$items['item'][$encontrar].'. ';
       }
   } // fin del foreach
   } // fin del if

// $pdf->Multicell(0,5,' '.$escribealumno,0,'J');
// $pdf->WriteHTML($escribealumno.'<br>');
// $pdf->Ln(2);

if ($escribealumno<>"") {
  $escribealumno=$escribealumno.'<br><br>'; 
  $pdf->SetFontSize(13);
  $pdf->WriteHTML($escribealumno); 
  // $pdf->Multicell(0,5,$escribealumno,0,'J');
}

if ($row['observaciones']<>"") {
  $incorporar="<b><i>Observaciones:</i></b> ".$row['observaciones'].'<br>';
  // $pdf->SetLeftMargin(15);
  $pdf->SetFontSize(13);
  $pdf->WriteHTML($incorporar);
}

$pdf->Ln(2);

} // fin del while
    
mysql_free_result($result);	

$pdf->Image("../fpdf17/hr-jon-lucas2.jpg",80,NULL,50);
// $pdf->Multicell(0,5,"----- o -----",0,'C');

} // fin del for each 

// Env�o el PDF
$pdf->Output($title1.'.pdf','I');

?>

