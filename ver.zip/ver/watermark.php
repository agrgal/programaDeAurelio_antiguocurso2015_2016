<?php 
$mpdf->showWatermarkImage = 1;
$mpdf->WriteHTML('<watermarkimage src="../imagenes_plantilla/logo45.png" alpha="0.1" size="F"/>');
?>
